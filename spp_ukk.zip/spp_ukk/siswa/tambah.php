<?php 
include '../koneksi.php';

include '../helper/Siswa.php';
include '../helper/Pembayaran.php';
include '../helper/Kelas.php';

khusus_admin();

$siswaObjek = new Siswa();
$pembayaranObjek = new Pembayaran();
$kelasObjek = new Kelas();

$semua_pembayaran = $pembayaranObjek->semua();
$semua_kelas = $kelasObjek->semua();
if ( isset($_POST['submit'])){
    $siswaObjek->tambah($_POST);
    header('location: index.php');
    die;
}
?>

<?php include('../sparepart/header.php');?>
    <h4> Tambah siswa </h4>
    <div class='card p-4'>
        <form action="" method='POST'>
            <div class='mb-2'>
                <label for="nis"> Nis</label>
                <input type="text" id='nis' name='nis' class='form-control'>
            </div>
            <div class='mb-2'>
                <label for="password"> Password</label>
                <input type="password" id='password' name='password' class='form-control'>
            </div>
            <div class='mb-2'>
                <label for="nama"> Nama</label>
                <input type="text" id='nama' name='nama' class='form-control'> 
            </div>
            <div class="mb-2">
                <label for="nisn">Nisn</label>
                <input type="text" id='nisn' name='nisn' class='form-control'>
            </div>
            <div class="mb-2">
                <label for="alamat">Alamat</label>
                <input type="text" id='alamat' name='alamat' class='form-control'>
            </div>
            <div class="mb-2">
                <label for="telepon">Telepon</label>
                <input type="number" id='telepon' name='telepon' class='form-control'>
            </div>

            <div class="mb-2">
                <label for="kelas_id">Kelas</label>
                <select name="kelas_id" id="kelas_id" class="form-control">
                    <?php foreach($semua_kelas as $kelas):?>
                        <option value="<?= $kelas['id']?>"><?= $kelas['nama']?></option>
                    <?php endforeach;?>
                </select>
            </div>

            <div class="mb-2">
                <label for="pembayaran_id">pembayaran</label>
                <select name="pembayaran_id" id="pembayaran_id" class="form-control">
                    <?php foreach($semua_pembayaran as $pembayaran):?>
                        <option value="<?= $pembayaran['id']?>"><?= $pembayaran['tahun_ajaran']?></option>
                    <?php endforeach;?>
                </select>
            </div>

            <button name='submit' class='btn btn-primary form-control'> Submit </button>
        </form>
    </div>
<?php include('../sparepart/footer.php');?>