<?php
include '../helper/function.php';
include '../helper/siswa.php';

khusus_admin();


// ID YANG DIBERIKAN ADALAH PENGGUNA_ID, AGAR TIDAK MENYULITKAN DALAM MELAKUKAN KUERI
$id = $_GET['id'];
$siswaObjek = new Siswa();

$siswaObjek->hapus($id);
header('location: index.php'); 
die;
