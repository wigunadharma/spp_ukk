<?php 
include '../helper/function.php';
include '../helper/pembayaran.php';

khusus_admin();


$pembayaranObjek = new Pembayaran();

if ( isset($_POST['submit'])){
    $pembayaranObjek->tambah($_POST);
    header('Location: index.php');
    die;
}
?>

<?php include('../sparepart/header.php');?>
    <h4> Tambah Pembayaran </h4>
    <div class='card p-4'>
        <form action="" method='POST'>
            <div class='mb-2'>
                <label for="nominal"> Nominal</label>
                <input type="number" id='nominal' name='nominal' class='form-control'>
            </div>
            <div class='mb-2'>
                <label for="tahun_ajaran"> Tahun Ajaran</label>
                <input type="number" id='tahun_ajaran' name='tahun_ajaran' class='form-control'> 
            </div>
            <button name='submit' class='btn btn-primary form-control'> Submit </button>
        </form>
    </div>
<?php include('../sparepart/footer.php');?>