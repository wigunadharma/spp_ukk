<?php
include '../helper/function.php';

include '../helper/Pembayaran.php';

khusus_admin();


$id = $_GET['id'];
$pembayaranObjek = new Pembayaran();

$pembayaranObjek->hapus($id);
header('location: index.php');
die;