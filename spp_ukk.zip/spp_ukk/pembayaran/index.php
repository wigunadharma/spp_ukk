<?php 
include '../helper/function.php';
include '../helper/pembayaran.php';

khusus_admin();


$pembayaranObjek = new Pembayaran();
$semua_pembayaran = $pembayaranObjek->semua();
?>

<?php include('../sparepart/header.php');?>
<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Daftar pembayaran</h1>
<a href="tambah.php" class="btn btn-success my-2">Tambah pembayaran</a>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">DataTables Pembayaran</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nominal</th>
                        <th>Tahun Ajaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($semua_pembayaran as $pembayaran):?>
                    <tr>    
                        <td><?= $pembayaran['nominal']?></td>
                        <td><?= $pembayaran['tahun_ajaran']?></td>
                        <td>
                            <a href="edit.php?id=<?= $pembayaran['id']?>" class="btn btn-warning"> Edit </a>
                            <a href="hapus.php?id=<?= $pembayaran['id']?>" class="btn btn-danger"> Hapus </a>
                        </td>
                    </tr>
                    <?php endforeach;?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include('../sparepart/footer.php');?>        