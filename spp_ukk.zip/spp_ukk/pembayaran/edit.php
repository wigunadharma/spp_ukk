<?php 
include '../helper/function.php';
include '../helper/pembayaran.php';

khusus_admin();

if (empty($_GET['id'])) {
    header('Location: index.php');
    die;
}
$id = $_GET['id'];
$pembayaranObjek = new Pembayaran();
$pembayaran = $pembayaranObjek->cari($id);

if( isset($_POST['submit']) ){
    $pembayaranObjek->update($id, $_POST);
}
?>

<?php include('../sparepart/header.php');?>
<h4> Edit Pembayaran</h4>
<div class="card py-3 px-4">
    <form action="" method="POST">
        <div class="mb-2">
            <label for="nominal"> Nominal</label>
            <input type="number" id="nomninal" name="nominal" class="form-control" value="<?=$pembayaran['nominal']?>">
        </div>
        <div>
            <label for="tahun_ajaran"> Tahun Ajaran</label>
            <input type="number" id="tahun_ajaran" name="tahun_ajaran" class="form-control" value="<?php echo($pembayaran['tahun_ajaran'])?>">
        </div>
        <button name="submit" class="btn btn-warning form-control mt-4"> Submit </button>
    </form>
</div>
<?php include('../sparepart/footer.php');?>      