<?php
include '../helper/function.php';
include '../helper/Transaksi.php';

khusus_back_office();

$tahun = $_GET['tahun'];

$transaksiObjek = new Transaksi();
$semua_bulan = [
    'Juli' => $transaksiObjek->total_pemasukan_bulan(7, $tahun),
    'Agustus' => $transaksiObjek->total_pemasukan_bulan(8, $tahun),
    'September' => $transaksiObjek->total_pemasukan_bulan(9, $tahun),
    'Oktober' => $transaksiObjek->total_pemasukan_bulan(10, $tahun),
    'Nopember' => $transaksiObjek->total_pemasukan_bulan(11, $tahun),
    'Desember' => $transaksiObjek->total_pemasukan_bulan(12, $tahun),
    'Januari' => $transaksiObjek->total_pemasukan_bulan(1, $tahun),
    'Februari' => $transaksiObjek->total_pemasukan_bulan(2, $tahun),
    'Maret' => $transaksiObjek->total_pemasukan_bulan(3, $tahun),
    'April' => $transaksiObjek->total_pemasukan_bulan(4, $tahun),
    'Mei' => $transaksiObjek->total_pemasukan_bulan(5, $tahun),
    'Juni' => $transaksiObjek->total_pemasukan_bulan(6, $tahun),
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan</title>
    <link rel="stylesheet" href="../css/sb-admin-2.min.css">
</head>
<body>
    <div class="table-responsive p-3">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Bulan</th>
                    <th>Jumlah Pemasukan</th>
                </tr>
            </thead>                
            <tbody>
                <?php foreach($semua_bulan as $nama_bulan => $pemasukan):?>
                <tr>
                    <td><?= $nama_bulan?></td>
                    <td><?= $pemasukan?></td>
                </tr>
                <?php endforeach;?>
            </tbody>
        </table>
    </div>
</body>

<script>
document.onload(window.print());
</script>

</html>